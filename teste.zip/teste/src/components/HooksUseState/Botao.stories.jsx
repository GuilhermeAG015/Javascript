import React from 'react'
import ExercicioHooks from '.';

export default {
    title: 'Exercicio/Hooks',
};

export const HooksEx = () => (
    <ExercicioHooks />
)