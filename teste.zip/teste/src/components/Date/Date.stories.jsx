import React from 'react'
import Data from '.';

export default {
    title: 'Exercicio/Data',
};

export const DataT = () => (
    <Data />
)