import React from 'react'
import ToDoList from '.';

export default {
    title: 'Exercicio/ToDo',
};

export const DataT = () => (
    <ToDoList />
)